
public class Cliente {
	private String nome;
	private String cpf;
	private String nacionalidade;
	private String telefone;
	private String endereco;

	public Cliente(String nome, String cpf, String nacionalidade, String telefone, String endereco) {
		this.nome = nome;
		this.cpf = cpf;
		this.nacionalidade = nacionalidade;
		this.telefone = telefone;
		this.endereco = endereco;
	}

	public String getNome() {
		return nome;
	}

	public String getCpf() {
		return cpf;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public String getTelefone() {
		return telefone;
	}

	public String getEndereco() {
		return endereco;
	}

	public String toString() {
		return "----------\n" + "Nome: " + this.getNome() + "\nCPF: " + this.getCpf() + "\nNacionalidade: "
				+ this.getNacionalidade() + "\nTelefone: " + this.getTelefone() + "\nEndereço: " + this.getEndereco()
				+ "\n------------";
	}
}