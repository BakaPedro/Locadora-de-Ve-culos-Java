
public class Veiculo {
	private String modelo;
	private String placa;
	private String tipoVeic;
	private int ano;
	private boolean status;

	public Veiculo(String modelo, String placa, String tipoVeic, int ano) {
		this.modelo = modelo;
		this.placa = placa;
		this.tipoVeic = tipoVeic;
		this.ano = ano;
		this.status = false;
	}

	public boolean stat() {
		return this.status = true;
	}

	public String getModelo() {
		return modelo;
	}

	public String getPlaca() {
		return placa;
	}

	public String getTipoVeic() {
		return tipoVeic;
	}

	public int getAno() {
		return ano;
	}

	public boolean isStatus() {
		return status;
	}

	public String valor(boolean x) {
		if (x) {
			return "Ocupado";
		} else {
			return "Disponível";
		}
	}

	public String toString() {
		return "-----------" + "\nNome: " + this.getModelo() + "\nPlaca: " + this.getPlaca() + "\nTipo de veículo: "
				+ this.getTipoVeic() + "\nAno: " + this.getAno() + "\nStatus: " + valor(this.isStatus())
				+ "\n-----------";
	}

}