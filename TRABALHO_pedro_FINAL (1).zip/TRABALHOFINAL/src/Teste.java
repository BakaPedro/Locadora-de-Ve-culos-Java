import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Teste {

	public static Cliente cli(Scanner scn) {
		System.out.println("Digite seu nome:");
		String nome = scn.nextLine();
		System.out.println("Digite seu CPF:");
		String cpf = scn.nextLine();
		System.out.println("Digite sua nacionalidade:");
		String nac = scn.nextLine();
		System.out.println("Digite seu número de telefone:");
		String tel = scn.nextLine();
		System.out.println("Digite seu endereço:");
		String end = scn.nextLine();
		Cliente c = new Cliente(nome, cpf, nac, tel, end);
		return c;
	}

	public static Veiculo vei(Scanner scn) {
		System.out.println("Digite o modelo do carro:");
		String modelo = scn.nextLine();
		System.out.println("Digite a placa:");
		String placa = scn.nextLine();
		System.out.println("Digite o tipo de veículo:");
		String tipV = scn.nextLine();
		System.out.println("Digite o ano do veículo:");
		int ano = scn.nextInt();
		Veiculo v = new Veiculo(modelo, placa, tipV, ano);
		return v;
	}

	public static Agencia agen(Scanner scn) {
		System.out.println("Digite o nome da agência:");
		String nome = scn.nextLine();
		System.out.println("Digite o endereço da agência:");
		String endereco = scn.nextLine();
		System.out.println("Digite o telefone da agência:");
		String numero = scn.nextLine();
		Agencia a = new Agencia(nome, endereco, numero);
		return a;
	}

	public static void menu() {
		System.out.println("[1] Cadastrar cliente");
		System.out.println("[2] Cadastrar veiculo");
		System.out.println("[3] Cadastrar agencia");
		System.out.println("[4] Registrar locação");
		System.out.println("[5] Realizar retirada");
		System.out.println("[6] Realizar devolução");
		System.out.println("[7] Cancelar locação");
		System.out.println("[8] Campo de exibição");
		System.out.println("[9] Lista de quantidades");
		System.out.println("[0] Sair");
	}

	public static void acao() {
		System.out.println("--------------------");
		System.out.println("[1] Realizar retirada");
		System.out.println("[2] Realizar devolução");
		System.out.println("[0] Sair");
	}

	public static void exibicao() {
		System.out.println("[1] Exibir clientes cadastrados");
		System.out.println("[2] Exibir veículos cadastrados");
		System.out.println("[3] Exibir agências cadastradas");
		System.out.println("[4] Exibir locações cadastradas");
		System.out.println("[0] Voltar");
	}

	public static int calc(String date, String date1) {
		DateTimeFormatter p = DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm");
		LocalDateTime a = LocalDateTime.parse(date, p);
		LocalDateTime b = LocalDateTime.parse(date1, p);
		Duration t1 = Duration.between(a, b);
		String dias = String.format("%d", t1.toDays());
		int i = Integer.valueOf(dias);
		return i;
	}
	public static void lista(int a, int b, int c,int d, ArrayList<Veiculo> f) {
		int g = 0;
		System.out.println("-----------------------");
		System.out.println("Agências registradas: "+ a);
		System.out.println("Clientes registrados: "+ b);
		System.out.println("Veículos registrados: "+ c);
		for(int i=0; i < c; i++) {
			if(!f.get(i).isStatus()) {
				g++;
			}
		}
		System.out.println("Veículos Disponíveis: "+ g);
		System.out.println("Locações registradas: "+ d);
		System.out.println("-----------------------");
	}

	public static void main(String[] args) {
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		ArrayList<Veiculo> veiculos = new ArrayList<Veiculo>();
		ArrayList<Agencia> agencias = new ArrayList<Agencia>();
		ArrayList<Locacao> locacoes = new ArrayList<Locacao>();

		Cliente c1 = new Cliente("PESSOA1", "131824814-29", "Brasil", "9999-9999", "rua tal tal, bairro tal tal");
		clientes.add(c1);
		Cliente c2 = new Cliente("PESSOA2", "231824814-29", "Brasil", "9999-9999", "rua tal tal, bairro tal tal");
		clientes.add(c2);
		Cliente c3 = new Cliente("PESSOA3", "331824814-29", "Brasil", "9999-9999", "rua tal tal, bairro tal tal");
		clientes.add(c3);
		Veiculo v1 = new Veiculo("Celta", "131JDA", "Automóvel", 2010);
		veiculos.add(v1);
		Veiculo v2 = new Veiculo("Palio", "231JDA", "Automóvel", 2012);
		veiculos.add(v2);
		Veiculo v3 = new Veiculo("Prisma", "331JDA", "Automóvel", 2016);
		veiculos.add(v3);
		Agencia a1 = new Agencia("AGENCIA1", "ENDERECO1", "19999-9999");
		agencias.add(a1);
		Agencia a2 = new Agencia("AGENCIA2", "ENDERECO2", "29999-9999");
		agencias.add(a2);
		Agencia a3 = new Agencia("AGENCIA3", "ENDERECO3", "39999-9999");
		agencias.add(a3);

		int op, a = 1, ac = 1, cl = 0;
		int i, ct = 0, c = 0, v = 0;
		int cD = 0;
		Scanner scn = new Scanner(System.in);
		do {
			menu();
			op = scn.nextInt();
			scn.nextLine();
			switch (op) {
			case 1:
				i = clientes.size();
				clientes.add(cli(scn));
				System.out.println(clientes.get(i).toString());
				break;
			case 2:
				i = veiculos.size();
				veiculos.add(vei(scn));
				System.out.println(veiculos.get(i).toString());
				break;
			case 3:
				i = agencias.size();
				agencias.add(agen(scn));
				System.out.println(agencias.get(i).toString());
				break;
			case 4:
				do {
					System.out.println("Cliente possui cadastro?");
					System.out.println("[1]SIM\n[2]NÃO\n[0]SAIR");
					i = scn.nextInt();
					scn.nextLine();
					if (i == 1) {
						cD = 0;
						ct = 0;
						System.out.println("Listando clientes cadastrados:");

						for (Cliente lista : clientes) {
							System.out.printf("[%d]-%s\n", ct++, lista);
						}
						System.out.println("Digite o número correspondente:");
						c = scn.nextInt();
						ct = 0;
						for (ct = 0; ct < veiculos.size(); ct++) {
							if (!veiculos.get(ct).isStatus())
								cD++;
						}
						if (cD > 0) {
							ct = 0;
							System.out.println("Listando veículos cadastrados:");
							for (Veiculo lista : veiculos) {
								System.out.printf("[%d]-%s\n", ct++, lista);
							}
							System.out.println("Digite o número correspondente:");
							v = scn.nextInt();
							while (veiculos.get(v).isStatus()) {
								System.out.println("Veículo ocupado - Selecione outro");
								System.out.println("Digite o número correspondente:");
								v = scn.nextInt();
							}

							veiculos.get(v).stat();
							Locacao loc = new Locacao(clientes.get(c), veiculos.get(v));
							locacoes.add(loc);
							break;
						}
						System.out.println("Nenhum veículo disponível!Volte mais tarde");
						break;

					} else if (i == 2) {
						clientes.add(cli(scn));
						i = 1;
					} else if (i == 0) {
					} else {
						System.out.println("Opção incorreta!!");
					}
				} while (i != 0);
				break;
			case 5:
				if (locacoes.size() > 0) {
					ct = 0;
					System.out.println("Escolha a locação desejada:");
					for (Locacao lista : locacoes) {
						System.out.printf("[%d]-%s\n", ct++, lista);
					}
					cl = scn.nextInt();
					System.out.println("Escolha a agência:");
					ct = 0;
					for (Agencia lista : agencias) {
						System.out.printf("[%d]-%s\n", ct++, lista);
					}
					ac = scn.nextInt();
					scn.nextLine();
					System.out.println("Digite a data e hora da retirada(dd/MM/yyyy HH:mm):");
					String data = scn.nextLine();
					locacoes.get(cl).status(agencias.get(ac), 1, data);
					break;
				} else
					System.out.println("Não existem locações ainda!");
				break;
			case 6:
				if (locacoes.size() > 0) {
					ct = 0;
					System.out.println("Escolha a locação desejada:");
					for (Locacao lista : locacoes) {
						System.out.printf("[%d]-%s\n", ct++, lista);
					}
					cl = scn.nextInt();
					if (locacoes.get(cl).isStatusRet()) {
						System.out.println("Escolha a agência:");
						ct = 0;
						for (Agencia lista : agencias) {
							System.out.printf("[%d]-%s\n", ct++, lista);
						}
						ac = scn.nextInt();
						scn.nextLine();
						System.out.println("Digite a data e hora da devolução(dd/MM/yyyy HH:mm):");
						String data = scn.nextLine();
						locacoes.get(cl).status(agencias.get(ac), 2, data);
						locacoes.get(cl).precoFinal(calc(locacoes.get(cl).getDataRet(), locacoes.get(cl).getDataDev()));
						break;
					} else {
						System.out.println("Realize a retirada primeiro!!");
						break;
					}
				} else
					System.out.println("Não existem locações ainda!");
				break;
			case 7:
				if (locacoes.size() > 0) {
					cD = 0;
					for (ct = 0; ct < locacoes.size(); ct++) {
						if (locacoes.get(ct).isStatusLoc())
							cD++;
					}
					System.out.println(cD);
					if (cD > 0) {
						do {
							ct = 0;
							System.out.println("Escolha a locação desejada:");
							for (Locacao lista : locacoes) {
								System.out.printf("[%d]-%s\n", ct++, lista);
							}
							cl = scn.nextInt();
							if (locacoes.get(cl).isStatusLoc()) {
								break;
							}
							System.out.println("Esta locação já está cancelada!");

						} while (cl == 01);
						locacoes.get(cl).cancelar();
						System.out.println("Cancelamento bem sucedido!");
						break;
					} else {
						System.out.println("Não há locações para serem canceladas!");
						break;
					}
				} else
					System.out.println("Não existem locações ainda!");
				break;
			case 8: 
				do {
					exibicao();
					a = scn.nextInt();
					scn.nextLine();
					switch (a) {
					case 1:
						for (Cliente lista : clientes) {
							System.out.println(lista);
						}
						break;
					case 2:
						for (Veiculo lista : veiculos) {
							System.out.println(lista);
						}
						break;
					case 3:
						for (Agencia lista : agencias) {
							System.out.println(lista);
						}
						break;
					case 4:
						if (locacoes.size() > 0) {
							for (Locacao lista : locacoes) {
								System.out.println(lista);
							}
							break;
						} else
							System.out.println("Ainda não há locações!");
						break;
					}
				} while (a != 0);
				break;
			case 9:
				lista(agencias.size(), clientes.size(), veiculos.size(), locacoes.size(), veiculos);
				break;
			}
		} while (op != 0);
		scn.close();
	}
}
