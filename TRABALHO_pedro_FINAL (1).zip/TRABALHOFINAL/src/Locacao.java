
public class Locacao {
	private Cliente cliente;
	private Veiculo veiculo;
	private Agencia agenciaRet;
	private Agencia agenciaDev;
	private boolean statusRet;
	private boolean statusDev;
	private String dataRet;
	private String dataDev;
	private boolean statusLoc;
	private double precoLoc;
	private double precoFin;

	public Locacao(Cliente cliente, Veiculo veiculo) {
		this.cliente = cliente;
		this.veiculo = veiculo;
		this.statusLoc = true;
		this.statusRet = false;
		this.statusDev = false;
		this.precoLoc = 65;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void status(Agencia agencia, int a, String data) {
		if (a == 1) {
			this.dataRet = data;
			this.agenciaRet = agencia;
			this.statusRet = true;
		} else if (a == 2 && this.statusRet) {
			this.dataDev = data;
			this.agenciaDev = agencia;
			this.statusDev = true;
		}
	}

	public Veiculo getVeiculo() {
		return veiculo;
	}

	public Agencia getAgenciaRet() {
		return agenciaRet;
	}

	public Agencia isAgenciaDev() {
		return agenciaDev;
	}

	public boolean isStatusRet() {
		return statusRet;
	}

	public boolean isStatusDev() {
		return statusDev;
	}

	public String getDataRet() {
		return dataRet;
	}

	public String getDataDev() {
		return dataDev;
	}

	public double getPrecoFin() {
		return precoFin;
	}

	public double getPrecoLoc() {
		return precoLoc;
	}

	public boolean isStatusLoc() {
		return statusLoc;
	}

	public boolean cancelar() {
		return this.statusLoc = false;
	}

	public double precoFinal(int a) {
		return (this.precoFin = this.getPrecoLoc() * a);
	}

	public String valor(boolean x, int a) {
		if (!x) {
			return "Cancelada";
		} else {
			if (a == 1) {
				return "Locação finalizada";
			}
			return "Em andamento";
		}
	}

	public String toString() {
		if (this.isStatusDev() && this.isStatusRet()) {
			return "------------\n" + this.getCliente() + "\n" + this.getVeiculo() + "\n" + "Retirada em: "
					+ this.getDataRet() + "\n" + this.getAgenciaRet() + "\n" + "Devolução em: " + this.getDataDev()
					+ "\n" + this.isAgenciaDev() + "\n" + "Status da locação: " + valor(this.isStatusLoc(), 1) + "\n"
					+ "Preço total:R$" + this.getPrecoFin() + "\n-----------";
		} else if (this.statusRet) {
			return "------------\n" + this.getCliente() + "\n" + this.getVeiculo() + "\n" + "Retirada em: "
					+ this.getDataRet() + "\n" + this.getAgenciaRet() + "\n" + "Devolução: Não realizada\n"
					+ "Status da locação: " + valor(this.isStatusLoc(), 0) + "\n-----------";
		} else {
			return "------------\n" + this.getCliente() + "\n" + this.getVeiculo() + "\n" + "Retirada: Não realizada"
					+ "\n" + "Devolução: Não realizada" + "\n" + "Status da locação: " + valor(this.isStatusLoc(), 0)
					+ "\n-----------";
		}
	}

}