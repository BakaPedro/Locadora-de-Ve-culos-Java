
public class Agencia {
	private String nome;
	private String endereco;
	private String numero;

	public Agencia(String nome, String endereco, String numero) {
		this.nome = nome;
		this.endereco = endereco;
		this.numero = numero;
	}

	public String getNome() {
		return nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public String getNumero() {
		return numero;
	}

	public String toString() {
		return "------------" + "\nNome: " + this.getNome() + "\nEndereço: " + this.getEndereco() + "\nTelefone: "
				+ this.getNumero() + "\n-----------";
	}

}